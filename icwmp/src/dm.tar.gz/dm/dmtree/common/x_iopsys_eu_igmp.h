#ifndef __SE_IGMP_H
#define __SE_IGMP_H

extern DMLEAF tSe_IgmpParam[];

#endif