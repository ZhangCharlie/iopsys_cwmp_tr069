#define PACKAGE_VERSION "3.0.0"

#define HAVE__STRNICMP 1
//#define HAVE_SPRINTF_S 1

// prevent pcap-int.h from redefining snprintf and vsnprintf
#define HAVE_SNPRINTF 1
#define HAVE_VSNPRINTF 1

#define HAVE_LIMITS_H 1

#define HAVE_LIBPCAP 1
#define HAVE_PCAP 1
#define HAVE_BPF_FILTER 1
#define HAVE_PCAP_H 1
#define HAVE_PCAP_BPF_H 1
#define HAVE_PCAP_INT_H 1
